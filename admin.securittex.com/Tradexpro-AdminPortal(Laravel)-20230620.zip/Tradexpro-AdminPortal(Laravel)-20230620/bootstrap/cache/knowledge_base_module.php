<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\KnowledgeBase\\Providers\\KnowledgeBaseServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\KnowledgeBase\\Providers\\KnowledgeBaseServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);