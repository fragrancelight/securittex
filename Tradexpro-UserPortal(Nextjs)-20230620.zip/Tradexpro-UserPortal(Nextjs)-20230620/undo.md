untouched api
get-all-sell-orders-app
get-coin-list
get-coin-pair-list
swap-coin-details-app
